Pour lancer le jeu, il faut entrer dans le dossier Scripts puis cliquer sur les fichers "compile.sh", "execute.sh" respectivement.

Attention !!

Dès qu'on lance les fichiers "compile.sh" et "execute.sh" sur windows, alors on peut plus les utiliser avec d'autres machines pour
lancer le jeu.

Dans le cas où le fichier ne s'execute pas sur votre machine, veullez utiliser les lines de commandes suivantes :

POUR LANCER LE JEU:
--- OUVREZ UN TERMINAL 
--- PLACEZ VOUS DANS LE DOSSIER "src"
--- PUIS ENTREZ CETTE COMMANDE : javac -d ../build *.java  POUR COMPILLER LE CODE
--- ENSUITE ENTREZ : java -cp ../build Demo
--- SELECTIONNER VOTRE MODE DE JEU

--------- VOUS COMMENCEZ UNE PARTIE DE BATAILLE NAVALE ---------------------------