////////////////////////////////////////////////////////////////////////
///////////////////---------BATAILLE NAVALE ------------////////////////
///////////////     ABOUBACAR SIMAGAN 21913221 L2 3A       /////////////
//////////////      ABOUBACAR KEITE            L2 3A       /////////////
//////////////      MAHAMAT AHMAT AHMAT        L2 3A       /////////////
////////////////////////////////////////////////////////////////////////
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
////////////////////////////////////////////////////////////////////////
/// CLASSE D'ETAT DE JEU, INITIALISATION DES GRILLES, ECHANGE DES TIRES
///////////////////////    CLASSE PRINCIPALE   /////////////////////////
public class State extends Player {
    // DECLARATION DES GRILLES POUR LES DEUX JOUEURS
    // A L'ETAT INITIAL,
    public Random rand;
    public  String[][] firstGrid = new String[10][10]; // GRILLE PREMIER JOUEUR
    public  String[][] secondGrid = new String[10][10];// GRILLE DEUXIEME JOUEUR
    public  String[] liste = new String[]{"A","B","C","D","E","F","G","H","I","J"}; // LISTE INDICES ALPHABETIQUE
    public  ArrayList<String> firstPlayerShoot = new ArrayList<>(Collections.emptyList()); // LISTE DE TIRE PREMIER JOUEUR
    public  ArrayList<String> secondPlayerShoot = new ArrayList<>(Collections.emptyList());// LISTE DE TIRE DEUXIEME JOUEUR
    public static final String empty = "."; // CASE VIDE
    public static final String engage = "X"; // CASE OCCUPEE PAR UN BATEAU
    public static final String damage = "+"; // UN BATEAU ENDOMMAGE
    public static final String missed = "o"; // TIRE RATE
    public static final String[] TWOBOAT = new String[]{"twoUp","twoDown","twoLeft","twoRight"}; // LISTE DES BATEAUX DE DEUX CASES
    public static final String[] TREEBOAT = new String[]{"treeUp","treeDown","treeLeft","treeRight"};// LISTE DES BATEAUX DE TROIS CASES
    public static final String[] FOUREBOAT = new String[]{"foureUp","foureDown","foureLeft","foureRight"};// LISTE DES BATEAUX DE QUATRE CASES
    public static final String[] FIVEBOAT = new String[]{"fiveUp","fiveDown","fiveLeft","fiveRight"}; // LISTE DES BATEAUX DE CINQ CASES

    //////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////
    public State(String firstPlyer, String secondPlayer) {
        super(firstPlyer,secondPlayer);
        rand = new Random();
    }
    /////////////////////////////////////////////////////////////////
    // INITIALISATION DES GRILLES A UN VIDE
    public void creatGrid(){
        for(int i = 0; i<10; i++)
            for(int j = 0; j<10; j++){
                firstGrid[i][j] = empty;
                secondGrid[i][j] = empty;
            }
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // L'AFFICHAGE EN STRING DES GRILLES
    public void displayGrid(String[][] g){
        System.out.println("   A  B  C  D  E  F  G  H  I  J ");
        for (int i = 0; i<10; i++) {
            System.out.print(i +"  ");
            for (int j = 0; j < 10; j++) {
                System.out.print(g[i][j]+"  ");
            }
            System.out.println(" ");

        }
    }
    /////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////
    // OBTENIR L'INDICE D'UNE LETTRE SUR L'HORIZONTAL AFIN DE
    // RENVOYER UN ENTIER POUR TROUVER LE CASE CORRESPONDANTE
    public int setIndice(String g){
        int j = 0;
        for(int p = 0; p<10; p++)
            if(liste[p].equals(g.toUpperCase()))
                j = p;
        return j;
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // VERIVIER SI LES BATEAUX COMPRIS ENTRE DEUX CASES PEUVENT ETRE
    // PLACE SELONS LES QUATRES (4) DIRECTIONS
    ///////////// DIRECTION VERS LE HAUT
    public boolean twoUpBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return i - 1 >= 0 && (grid[i][j].equals(empty) && grid[i - 1][j].equals(empty));
    }
    ///////////////
    // DIRECTION VERS LE BAS
    public boolean twoDownBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return i + 1 < 10 && (grid[i][j].equals(empty) && grid[i + 1][j].equals(empty));
    }
    ///////////////
    /// DIRECTION VERS LA GAUCHE
    public boolean twoLeftBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return j - 1 >= 0 && (grid[i][j].equals(empty) && grid[i][j - 1].equals(empty));
    }
    ///////////////
    /// DIRECTION VERS LA DROITE
    public boolean twoRightBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return j + 1 < 10 && (grid[i][j].equals(empty) && grid[i][j + 1].equals(empty));
    }
    //////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////
    // VERIFIER SI LES BATEAUX COMPRIS ENTRE TROIS CASES PEUVENT ETRE
    // PLACE SELONS LES QUATRES (4) DIRECTIONS
    ///////////////////////////////////////////////////////////////////
    ///////  MEME CHOSE POUR LES BATEUX DE TROIS CASE.
    public boolean treeUpBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return i - 2 >= 0 && (grid[i][j].equals(empty) && grid[i - 1][j].equals(empty) && grid[i - 2][j].equals(empty));
    }
    ////////////////
    //
    public boolean treeDownBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return i + 2 < 10 && (grid[i][j].equals(empty) && grid[i + 1][j].equals(empty) && grid[i + 2][j].equals(empty));
    }
    ///////////////
    public boolean treeLeftBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return j - 2 >= 0 && (grid[i][j].equals(empty) && grid[i][j - 1].equals(empty) && grid[i][j - 2].equals(empty));
    }
    ///////////////
    public boolean treeRightBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        return j + 2 < 10 && (grid[i][j].equals(empty) && grid[i][j + 1].equals(empty) && grid[i][j + 2].equals(empty));
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // VERIFIER SI LES BATEAUX COMPRIS ENTRE QUATRE CASES PEUVENT ETRE
    // PLACE SELONS LES QUATRES (4) DIRECTIONS
    /////////////////////////////////////////////////////////////////
    ///// MEME CHOSE POUR LES BATEAUX DE QUATRE CASES
    public boolean foureUpBoat(String g , int i, String[][] grid){
        return twoUpBoat(g, i, grid) && twoUpBoat(g, i - 2, grid);
    }
    ///////////////////
    public boolean foureDownBoat(String g , int i, String[][] grid){
        return twoDownBoat(g, i, grid) && twoDownBoat(g, i + 2, grid);
    }
    ////////////////////
    public boolean foureLeftBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        if(j-3 >= 0 && (grid[i][j].equals(empty) && grid[i][j-1].equals(empty)))
            return grid[i][j - 2].equals(empty) && grid[i][j - 3].equals(empty);
        return false;
    }
    ////////////////////
    public boolean foureRightBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        if(j+3 < 10 && (grid[i][j].equals(empty) && grid[i][j+1].equals(empty)))
            return grid[i][j + 2].equals(empty) && grid[i][j + 3].equals(empty);
        return false;
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // VERIFIER SI LES BATEAUX COMPRIS ENTRE CINQ CASEs PEUVENT ETRE
    // PLACE SELONS LES CINQ (5) DIRECTIONS
    /////////////////////////////////////////////////////////////////
    ///// EET ENFIN POUR LES BATEAUX DE CINQ CASES
    public boolean fiveUpBoat(String g , int i, String[][] grid){
        return treeUpBoat(g, i, grid) && twoUpBoat(g, i - 4, grid);
    }
    public boolean fiveDownBoat(String g , int i, String[][] grid){
        return treeDownBoat(g, i, grid) && twoDownBoat(g, i + 4, grid);
    }
    ///////////////
    public boolean fiveLeftBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        if(j-4 >= 0 && (grid[i][j].equals(empty) && grid[i][j-1].equals(empty)))
            return grid[i][j - 2].equals(empty) && grid[i][j - 3].equals(empty) && grid[i][j - 4].equals(empty);
        return false;
    }
    public boolean fiveRightBoat(String g , int i, String[][] grid){
        int j = setIndice(g);
        if(j+4 < 10 && (grid[i][j].equals(empty) && grid[i][j+1].equals(empty)))
            return grid[i][j + 2].equals(empty) && grid[i][j + 3].equals(empty) && grid[i][j + 4].equals(empty);
        return false;
    }

    ////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////
    // PLACER LES BATEAUX DE DEUX CASES
    public void generateTwoBoat(String[][] grid, String boat){

        int i = this.rand.nextInt(10);
        int j = this.rand.nextInt(10);
        switch (boat) {
            case "twoUp" -> {
                while (!(twoUpBoat(liste[j], i, grid))) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i - 1][j] = engage;
            }
            case "twoDown" -> {
                while (!twoDownBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i + 1][j] = engage;
            }
            case "twoLeft" -> {
                while (!twoLeftBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j - 1] = engage;
            }
            case "twoRight" -> {
                while (!twoRightBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j + 1] = engage;
            }
        }
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // PLACER LES BATEAUX DE TROIS CASES
    public void generateTreeBoat(String[][] grid, String boat){
        int i = rand.nextInt(10);
        int j = rand.nextInt(10);
        switch (boat) {
            case "treeUp" -> {
                while (!treeUpBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i - 1][j] = engage;
                grid[i - 2][j] = engage;
            }
            case "treeDown" -> {
                while (!treeDownBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i + 1][j] = engage;
                grid[i + 2][j] = engage;
            }
            case "treeLeft" -> {
                while (!treeLeftBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j - 1] = engage;
                grid[i][j - 2] = engage;
            }
            case "treeRight" -> {
                while (!treeRightBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j + 1] = engage;
                grid[i][j + 2] = engage;
            }
        }
    }

    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // PLACER LES BATEAUX DE QUATRE CASES
    public void generateFoureBoat(String[][] grid, String boat){
        int i = rand.nextInt(10);
        int j = rand.nextInt(10);
        switch (boat) {
            case "foureUp" -> {
                while (!foureUpBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i - 1][j] = engage;
                grid[i - 2][j] = engage;
                grid[i - 3][j] = engage;
            }
            case "foureDown" -> {
                while (!foureDownBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i + 1][j] = engage;
                grid[i + 2][j] = engage;
                grid[i + 3][j] = engage;
            }
            case "foureLeft" -> {
                while (!foureLeftBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j - 1] = engage;
                grid[i][j - 2] = engage;
                grid[i][j - 3] = engage;
            }
            case "foureRight" -> {
                while (!foureRightBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j + 1] = engage;
                grid[i][j + 2] = engage;
                grid[i][j + 3] = engage;
            }
        }
    }

    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // PLACER LES BATEAUX DE CINQ CASES
    public void generateFiveBoat(String[][] grid, String boat){
        int i = rand.nextInt(10);
        int j = rand.nextInt(10);
        switch (boat) {
            case "fiveUp" -> {
                while (!fiveUpBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i - 1][j] = engage;
                grid[i - 2][j] = engage;
                grid[i - 3][j] = engage;
                grid[i - 4][j] = engage;
            }
            case "fiveDown" -> {
                while (!fiveDownBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i + 1][j] = engage;
                grid[i + 2][j] = engage;
                grid[i + 3][j] = engage;
                grid[i + 4][j] = engage;
            }
            case "fiveLeft" -> {
                while (!fiveLeftBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j - 1] = engage;
                grid[i][j - 2] = engage;
                grid[i][j - 3] = engage;
                grid[i][j - 4] = engage;
            }
            case "fiveRight" -> {
                while (!fiveRightBoat(liste[j], i, grid)) {
                    i = rand.nextInt(10);
                    j = rand.nextInt(10);
                }
                grid[i][j] = engage;
                grid[i][j + 1] = engage;
                grid[i][j + 2] = engage;
                grid[i][j + 3] = engage;
                grid[i][j + 4] = engage;
            }
        }
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // GENERER L'ETAT INITIAL DES CINQ DIFFERENTS BATEAUX
    public void getRandomInitialBoat(String[][] grid){
        int twoH = rand.nextInt(4);
        int twoV = rand.nextInt(4);
        int tree = rand.nextInt(4);
        int foure = rand.nextInt(4);
        int five = rand.nextInt(4);
        generateTwoBoat(grid,TWOBOAT[twoH]);
        generateTwoBoat(grid,TWOBOAT[twoV]);
        generateTreeBoat(grid,TREEBOAT[tree]);
        generateFoureBoat(grid,FOUREBOAT[foure]);
        generateFiveBoat(grid,FIVEBOAT[five]);

    }
    /////////////////////////
    // INITIALISATION DE L'ETAT DE GRILLE DES DEUX JOUEURS
    // TOUS LES BATEAUX SONT CHARGES //
    public void getInitialState(){
        getRandomInitialBoat(firstGrid);
        getRandomInitialBoat(secondGrid);
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////


    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    // TIRE SUR LES BATEAUX ADVERSE
    public void shoot(String[][] opposing, int i, String k, ArrayList<String> liste){
        int j = setIndice(k);
        if(opposing[i][j].equals(engage))
            opposing[i][j] = damage;
        else if (!opposing[i][j].equals(engage))
            if (getCurrentPlayer().equals(firstPlayer) && !firstGrid[i][j].equals(engage) && !firstGrid[i][j].equals(damage) && !secondGrid[i][j].equals("+"))
                firstGrid[i][j] = missed;
            else if(getCurrentPlayer().equals(secondPlayer) && !secondGrid[i][j].equals(engage) && !secondGrid[i][j].equals(damage) && !firstGrid[i][j].equals("+"))
                secondGrid[i][j] = missed;
        liste.add(k+i);
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    //////////  JOUEUR HUMAIN JOUE UN COUP S'IL EST LE JOUEUR COURANT
    public void humanPlay(String j , int i){
        if(getCurrentPlayer().equals(firstPlayer)){
            shoot(secondGrid,i,j,firstPlayerShoot);
            setCurrentPlayer(secondPlayer);
        }

    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    /// LA PARTIE POUR LA MACHINE
    /// LA BOUCLE WHILE POUR EVITER DE TIRER LE MEME COUP DEUX FOIS
    public void machinePlay(){
        if(getCurrentPlayer().equals(secondPlayer)){
            int i = rand.nextInt(10);
            int k = rand.nextInt(10);
            String j = liste[k];
            while(secondPlayerShoot.contains(j+i)){
                i = rand.nextInt(10);
                k = rand.nextInt(10);
                j = liste[k];
            }
            shoot(firstGrid,i,j,secondPlayerShoot);
            setCurrentPlayer(firstPlayer);
        }
    }
/////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////
    // UNE COPIE POUR JOUER ENTRE DEUX MACHINES
    public void randomMachinePlay(){
        if(getCurrentPlayer().equals(firstPlayer)){
            int i = rand.nextInt(10);
            int k = rand.nextInt(10);
            String j = liste[k];
            while(firstPlayerShoot.contains(j+i)){
                i = rand.nextInt(10);
                k = rand.nextInt(10);
                j = liste[k];
            }
            shoot(secondGrid,i,j,firstPlayerShoot);
            setCurrentPlayer(secondPlayer);
        }
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    ///// UN COMPTEUR POUR CONNAITRE LE NOMBRE DE BATEAUX POUR CHAQUE
    ///// JOUEUR AFIN D'IMPOSER UNE CONDITION DE TERMINAISON
    public int compteur(String[][] g){
        int c = 0;
        for (int i = 0; i<10; i++)
            for (int j = 0; j < 10; j++)
                if (g[i][j].equals(engage))
                    c += 1;
            return  c;
    }
    /////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////
    /// COPNDITION DE TERMINAISON
    public boolean isOver(){
        if(compteur(firstGrid) == 0)
            return  true;
        else return compteur(secondGrid) == 0;
    }

    //////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////
    // LE GAGNANT
    public void getWinner() {
        if (isOver()) {
            if (compteur(firstGrid)==0) {
                System.out.println("---- GAME OVER !! ---- \n");
                System.out.println(" The Winner is : " + getName(secondPlayer));
            } else if (compteur(secondGrid)==0) {
                System.out.println("---- GAME OVER !! ---- \n");
                System.out.println(" The Winner is : " + getName(firstPlayer));
            }
        }
    }
}
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////     FIN DE LA CLASSE    ///////////////////////////////