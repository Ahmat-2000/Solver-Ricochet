////////////////////////////////////////////////////////////////////////
///////////////////---------BATAILLE NAVALE ------------////////////////
///////////////     ABOUBACAR SIMAGAN 21913221 L2 3A       /////////////
//////////////      ABOUBACAR KEITE            L2 3A       /////////////
//////////////      MAHAMAT AHMAT AHMAT        L2 3A       /////////////
////////////////////////////////////////////////////////////////////////
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
///////  CLASSE DE JEU SUR L'INTERFACE
public class Interface extends JFrame {
    public Interface(){
        super("----------------------------BATAILLE NAVALE-----------------------------");
        setSize(new Dimension(860,600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        /////////////////////////////////////////////////////////////////////
        // CONVERSION DU CONTENU EN JPANEL
        JPanel contener = (JPanel) getContentPane();
        contener.setBorder(new EmptyBorder(20,10,20,0));
        contener.setLayout(new FlowLayout(FlowLayout.CENTER,10,0));
        contener.setBackground(Color.PINK);
        ////////////////////////////////////////////////////////////////////
        /// GENERER UN NOUVEL ETAT DE JEU
        State s = new State("HUMAN PLAYER","MACHINE PLAYER");
        s.creatGrid();
        s.getInitialState();
        //////////////////////////////////////////////////////////////////////
        // DESSINER LA GRILLE POUR CHAQUE JOUEURS
        Draw draw = new Draw(s.firstGrid);
        Draw draw2 = new Draw(s.secondGrid);
        draw.setToolTipText(s.getName(s.firstPlayer));
        draw2.setToolTipText(s.secondPlayer);
        ///////////////////////////////////////////////
        ///////////////////////////////////////////////
        // BOUTON POUR REPRENDRE UNE PARTIE
        JButton replay = new JButton("REPLAY");
        replay.setSize(new Dimension(50,50));
        replay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Interface();
            }
        });

        ///////////////////////////////////////////////
        //////////////////////////////////////////////
        // BOUTON POUR QUITER LE JEUX
        JButton quite = new JButton("QUITE");
        quite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        ////////////////////////////////////////////////
        ///////////////////////////////////////////////
        JPanel button = new JPanel();
        button.setPreferredSize(new Dimension(700,100));
        button.setBorder(new EmptyBorder(20,0,0,0));
        button.setLayout(new FlowLayout(FlowLayout.CENTER,30,0));
        button.add(replay);
        button.add(quite);
        ////////////////////////////////////////////////
        ////////////////////////////////////////////////
        contener.add(draw);
        contener.add(draw2);
        contener.add(button);
        ///////////////////////////////////////////////
        ///////////////////////////////////////////////
        quite.setBackground(Color.red);
        replay.setBackground(Color.GREEN);
        button.setBackground(Color.PINK);
        ///////////////////////////////////////////////
        ///////////////////////////////////////////////
        //// MASQUER LA GRILLE DU JOUEUR MACHINE
        draw2.setVisible(false);
        //////////////////////////////////////////////
        //////////////////////////////////////////////
        // JOUER A L'AIDE DE LA SOURIS POUR L'HUMAIN
        draw.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                s.humanPlay(s.liste[e.getX()/40],e.getY()/40);
                s.machinePlay();
                repaint();
                /////////////////////////////////
                // SI C'EST L'HUMAIN QUI GAGNE LA PARTIE
                if (draw2.over()){
                    JOptionPane.showMessageDialog(contener,"++++++  GAME IS OVER: HUMAN PLAYER WIN THE GAME +++++++");
                    draw2.setVisible(true);
                    repaint();
                }
                //////////////////////////////////
                // SI C'EST LA MACHINE QUI GAGNE LA PARTIE
                else if (draw.over()){
                    JOptionPane.showMessageDialog(contener,"++++++  GAME IS OVER: MACHINE PLAYER WIN THE GAME +++++++");
                    draw2.setVisible(true);
                    repaint();
                }
                repaint();
            }
        });
    }

}
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//////////////////////////      FIN DE LA CLASSE        /////////////////////////////