////////////////////////////////////////////////////////////////////////
///////////////////---------BATAILLE NAVALE ------------////////////////
///////////////     ABOUBACAR SIMAGAN 21913221 L2 3A       /////////////
//////////////      ABOUBACAR KEITE            L2 3A       /////////////
//////////////      MAHAMAT AHMAT AHMAT        L2 3A       /////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
//// CLASSE DES JOUEURS
public abstract class Player{
    public String firstPlayer; // PREMIER JOUEUR
    public String secondPlayer; // DEUXIEME JOUEUR
    public String currentPlayer; // JOUEUR COURANT
    public Player(String first, String second){
        firstPlayer = first;
        secondPlayer = second;
        currentPlayer = firstPlayer;
    }

    ///////////////////////////////////////////////////
    // OBTENIR LE JOUEUR COURANT
    public String getCurrentPlayer(){
        return currentPlayer;
    }
    ///////////////////////////////////////////////////
    /// INITILISATION DU JOUEUR COURANT
    public void setCurrentPlayer(String player){
        currentPlayer = player;
    }
    ///////////////////////////////////////////////////
    /// OBTENIR LE NOM D'UN JOUEUR
    public String getName(String player){
        return player;
    }
}
////////////////////////////////////////////////////////
//////////// FIN DE LA CLASSE       ////////////////////
