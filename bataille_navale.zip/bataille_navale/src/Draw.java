////////////////////////////////////////////////////////////////////////
///////////////////---------BATAILLE NAVALE ------------////////////////
///////////////     ABOUBACAR SIMAGAN 21913221 L2 3A       /////////////
//////////////      ABOUBACAR KEITE            L2 3A       /////////////
//////////////      MAHAMAT AHMAT AHMAT        L2 3A       /////////////
////////////////////////////////////////////////////////////////////////
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
// CLASSE QUI DESSINE L'INTERFACE GRAPHIQUE DU JEUX
public class Draw extends JPanel {
    public String[][] grid;
    public Draw(String[][] g){
        this.grid = g;
        setPreferredSize(new Dimension(400,400));
        GridLayout layout = new GridLayout(10,10);
        setLayout(layout);
        setBorder(new EmptyBorder(0,10,0,0));
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setBackground(Color.CYAN);

    }
////////////////////////////////////////////////////////////////////////
    /// GRAPHIQUE DU FOND, DES CAREAUX ET DES BATEAUX
    public void drawGrid(Graphics g){
        for (int i = 0; i < 10; i++){
            for (int j = 0; j< 10; j++){
                g.drawLine(0, (i*40), this.getWidth(), (i*40));
                g.drawLine((j*40), 0, (j*40), this.getHeight());
                if (!grid[i][j].equals(State.empty) && !grid[i][j].equals(State.missed))
                    g.drawImage(getToolkit().getImage("../image/navy1.png"),j*40-5,i*40-5,this);

            }
        }
    }
    /////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////
    /// GRAPHIQUE DES TIRES MANQUER ET NON MARQUER
    public void drawMissed(Graphics g) {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (grid[i][j].equals(State.missed)) {
                    g.drawImage(getToolkit().getImage("../image/wrong.png"), j * 40, (i) * 40, this);
                }
                else if(grid[i][j].equals("+")) {
                    g.drawImage(getToolkit().getImage("../image/navy1.png"),j*40-5,i*40-5,this);
                    g.drawImage(getToolkit().getImage("../image/feu.png"), j * 40, i * 40, this);
                }

            }
        }
    }

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////
    // GAME OVER SUR L'INTERFACE
    public boolean over(){
        for (int i = 0; i<10;i++){
            for (int j = 0; j<10;j++){
                if(grid[i][j].equals(State.engage))
                    return false;
            }
        }
        return true;
    }

    ////////////////////////////////////////////////////////////////////////
    /// L'APPEL DES METHODES POUR INILIALISER LE GRAPHIQUE
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        drawGrid(g2);
        drawMissed(g2);
    }

}
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
///////////////////////  FIN DE LA CLASSE     ///////////////////////////////