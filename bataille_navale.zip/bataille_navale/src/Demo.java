////////////////////////////////////////////////////////////////////////
///////////////////---------BATAILLE NAVALE ------------////////////////
///////////////     ABOUBACAR SIMAGAN 21913221 L2 3A       /////////////
//////////////      ABOUBACAR KEITE            L2 3A       /////////////
//////////////      MAHAMAT AHMAT AHMAT        L2 3A       /////////////
////////////////////////////////////////////////////////////////////////
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
/////////////////////////////////////////////////////////////////////////
//// JOUEUR UNE PARTIE DE BATAILLE NAVALE
public class Demo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("-----------------------------------------------BATAILLE NAVALE---------------------------------------");
        frame.setSize(new Dimension(700,200));
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
        ///////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////
        JPanel contener = (JPanel) frame.getContentPane();
        contener.setBorder(new EmptyBorder(20,10,0,10));
        contener.setLayout(new FlowLayout(FlowLayout.CENTER,10,0));

        ///////////////////////////////////////////////////////////
        // CHOISIR ENTER JOUEUR SUR L'INTERFACE OU CONSOLE
        JButton inter = new JButton("INTERFACE");
        JButton console = new JButton("CONSOLE: (HUMAN VS MACHIN)");
        JButton console2 = new JButton("CONSOLE: (MACHIN VS MACHIN)");
        JLabel label = new JLabel();
        JLabel label1 = new JLabel();
        label1.setBorder(new EmptyBorder(0,0,50,0));
        label.setText("WELCOME TO THE NAVAL BATTLE GAME");
        label1.setText(" YOU MUST CHOOSE A METHOD OF PLAYING FROM THESE METHODS: CONSOLE OR INTERFACE ");
        ///////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////
        contener.add(label);
        contener.add(label1);
        contener.add(inter);
        contener.add(console);
        contener.add(console2);
                
        JOptionPane.showMessageDialog(frame," YOU CAN PLAY TWO MACHINES IN CONSOLE TO MAKE THE GAME EASIER !!!!");

        ///////////////////////////////////////////////////////////////
        //// INTERFACE
        inter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                Interface fenetre =  new Interface();
                JOptionPane.showMessageDialog(inter," !! POUR JOUER !! CLIQUEZ SUR UNE CASE POUR LANCER UN TIRE ");
            }
        });

        //////////////////////////////////////////////////////
        //////////////////////////////////////////////////////
        // CONSOLE: MACHINE CONTRE HUMAIN
        console.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                JOptionPane.showMessageDialog(console,"POUR JOUER!! VOUS DEVEZ ENTRER UNE COORDONNEE ALPHABETIQUE DE A a Z PUIS NUMERIQUE DE 0 a 9 ");
                JOptionPane.showMessageDialog(console,"LES TIRES MANQUER SONT SIGNALES SUR VOTRE GRILLE PAR << o >> ET VOS BATEAUX ENDOMMAGES PAR << + >>");
                State state = new State("Human","Machine");
                Scanner enter = new Scanner(System.in);
                state.creatGrid();
                state.getInitialState();
                while (!state.isOver()){
                    System.out.println("------- VOTRE FLOTTE -----------");
                    state.displayGrid(state.firstGrid);
                    System.out.println("------- VOTRE LISTE DE COUPS TIRER -----------");
                    System.out.println(state.firstPlayerShoot +"\n");
                    System.out.println("Entrer un indice horital de A a J ou (a .. z) puis tapez sur ENTRER");
                    String letter = enter.next();
                    System.out.println("Enter l'indice vertical de 0 a 9 PUIS TAPEZ SUR ENTRER");
                    int number = enter.nextInt();

                    while(state.firstPlayerShoot.contains(letter.toUpperCase() + number)){
                        System.out.println(" !!!!!! Vous avez deja tirer a ce endroit !!!!!! ");
                        System.out.println(" !!!!!! Veillez Entrer un indice horital de A a J !!!!");
                        letter = enter.next();
                        System.out.println(" !!!!!! Enter l'indice vertical de 0 a 9 !!!!!!");
                        number = enter.nextInt();
                    }
                    state.humanPlay(letter.toUpperCase(),number);
                    state.machinePlay();


                }
                state.getWinner();
                System.out.println("------- VOTRE FLOTTE -----------");
                state.displayGrid(state.firstGrid);
                System.out.println("------- LA LISTE DE COUPS POUR LA MACHINE --------- \n "+state.secondPlayerShoot);
                System.out.println("------- LA GRILLE POUR LA MACHINE ------------");
                state.displayGrid(state.secondGrid);
            }
        });


        // CONSOLE: MACHINE CONTRE MACHINE
        console2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                JOptionPane.showMessageDialog(console2,"DEUX MACHINES S'AFFRONTENT: CLIQUEZ SUR 'OK' POUR COMMENCER" );
                State state = new State("FirstMachine","SecondMachine");
                state.creatGrid();
                state.getInitialState();
                while (!state.isOver()){
                    System.out.println("------- FLOTTE FIRST_MACHINE -----------");
                    state.displayGrid(state.firstGrid);
                    System.out.println("------- LISTE DE COUPS FIRST_MACHINE -----------");
                    System.out.println(state.firstPlayerShoot +"\n");
                    System.out.println("#########################################################");
                    System.out.println("------- FLOTTE SECOND_MACHINE -----------");
                    state.displayGrid(state.secondGrid);
                    System.out.println("------- LISTE DE COUPS SECOND_MACHINE -----------");
                    System.out.println(state.secondPlayerShoot +"\n");
                    state.randomMachinePlay();
                    state.machinePlay();

                }
                System.out.println("++++++++++++++++++++ FLOTTE FIRST_MACHINE +++++++++++++++++++++++");
                state.displayGrid(state.firstGrid);
                System.out.println("++++++++++++++++++++ LISTE DE COUPS FIRST_MACHINE ++++++++++++++++++++");
                System.out.println(state.firstPlayerShoot +"\n");
                System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                System.out.println("++++++++++++++++++++ FLOTTE SECOND_MACHINE ++++++++++++++++++++++");
                state.displayGrid(state.secondGrid);
                System.out.println("++++++++++++++++++++ LISTE DE COUPS SECOND_MACHINE ++++++++++++++++++++");
                System.out.println(state.secondPlayerShoot +"\n");
                System.out.println("++++++++++++++++++++++++++++++++");
                state.getWinner();
                System.out.println("++++++++++++++++++++++++++++++++");

            }
        });


    }
}
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
/////////////////////       FIN DE LA CLASSE        ///////////////////////